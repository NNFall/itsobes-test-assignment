# Черновик сообщения для отправки

Никита Владимирович, здравствуйте!

Направляю выполненное тестовое задание на вакансию IT-специалиста.

В составе:

- Задача 1: веб-утилита `IP Subnet Helper` для расчета IPv4/CIDR и планирования подсетей.
- Задача 2: Python-скрипт с обращением к API ЦБ РФ, обработкой данных и Dockerfile.
- Задача 3: Apps Script для Google Таблицы с обращением к тому же API и записью обработанных данных в таблицу.

Ссылки:

- Репозиторий: https://github.com/NNFall/itsobes-test-assignment
- ZIP-архив: http://5.129.236.90:8088/downloads/itsobes_test_assignment.zip
- Серверная страница проекта: http://5.129.236.90:8088/
- Веб-утилита: http://5.129.236.90:8088/task1/
- Google Таблица: https://docs.google.com/spreadsheets/d/1kdPwyJNoY0iTCd0_MdIvStNLT5dNHc4ydRLRrwywBfE/edit?usp=sharing

Внутри проекта есть README, описание процесса работы с AI, инструкции по запуску, пример вывода Python-скрипта и финальный документ `docs/final_submission.md`.

С уважением,
Никита
